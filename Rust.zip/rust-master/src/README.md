This directory contains the source code of the rust project, including:
- `rustc` and its tests
- `libstd`
- Various submodules for tools, like rustdoc, rls, etc.

For more information on how various parts of the compiler work, see the [rustc dev guide].

[rustc dev guide]: https://rustc-dev-guide.rust-lang.org/about-this-guide.html
