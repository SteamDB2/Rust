% The (old) Rust Testing Guide

This content has moved into
[the Rust Programming Language book](book/ch11-00-testing.html).
