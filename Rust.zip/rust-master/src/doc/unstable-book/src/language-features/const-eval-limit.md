# `const_eval_limit`

The tracking issue for this feature is: [#67217]

[#67217]: https://github.com/rust-lang/rust/issues/67217

The `const_eval_limit` allows someone to limit the evaluation steps the CTFE undertakes to evaluate a `const fn`.
