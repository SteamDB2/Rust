# `is_sorted`

The tracking issue for this feature is: [#53485]

[#53485]: https://github.com/rust-lang/rust/issues/53485

------------------------

Add the methods `is_sorted`, `is_sorted_by` and `is_sorted_by_key` to `[T]`;
add the methods `is_sorted`, `is_sorted_by` and `is_sorted_by_key` to
`Iterator`.
