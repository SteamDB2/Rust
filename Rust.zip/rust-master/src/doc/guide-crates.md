% The (old) Rust Crates and Modules Guide

This content has moved into
[the Rust Programming Language book](book/crates-and-modules.html).
