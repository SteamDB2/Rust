% Error Handling in Rust

This content has moved into
[the Rust Programming Language book](book/ch09-00-error-handling.html).
