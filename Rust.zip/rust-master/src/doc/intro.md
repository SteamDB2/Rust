% A 30-minute Introduction to Rust

This introduction is now deprecated. Please see [the introduction to the book][intro].

[intro]: book/README.html
