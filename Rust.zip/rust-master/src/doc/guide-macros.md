% The (old) Rust Macros Guide

This content has moved into
[the Rust Programming Language book](book/macros.html).
