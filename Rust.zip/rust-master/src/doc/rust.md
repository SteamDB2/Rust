% The Rust Reference Manual

The manual has moved, and is now called [the reference](reference/index.html).
