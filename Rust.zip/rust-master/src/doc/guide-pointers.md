% The Rust Pointer Guide

This content has been removed, with no direct replacement. Rust only
has two built-in pointer types now,
[references](book/ch04-02-references-and-borrowing.html) and [raw
pointers](book/raw-pointers.html). Older Rusts had many more pointer
types, they’re gone now.
