% The (old) Rust Ownership Guide

This content has moved into
[the Rust Programming Language book](book/ch04-00-understanding-ownership.html).
