% The (old) Guide to Rust Strings

This content has moved into
[the Rust Programming Language book](book/strings.html).
