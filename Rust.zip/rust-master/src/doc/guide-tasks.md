% The (old) Rust Threads and Communication Guide

This content has moved into
[the Rust Programming Language book](book/concurrency.html).
